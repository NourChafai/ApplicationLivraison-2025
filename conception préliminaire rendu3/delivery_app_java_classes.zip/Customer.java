import java.util.List;

public class Customer extends Person {

    public void passerCommande(Menu menu, Restaurant restaurant) {
        List<Item> listeItems = menu.afficherItems();
        List<Item> itemsChoisis = selectionnerItems(listeItems);

        Order commande = new Order(itemsChoisis, this, restaurant);
        commande.setStatus(OrderStatus.PENDING);

        boolean confirmation = restaurant.enregistrerCommande(commande);

        if (confirmation) {
            System.out.println("Commande enregistrée avec succès !");
        } else {
            System.out.println("Erreur lors de l'enregistrement de la commande.");
        }
    }

    private List<Item> selectionnerItems(List<Item> menuItems) {
        return menuItems.subList(0, Math.min(2, menuItems.size()));
    }
}