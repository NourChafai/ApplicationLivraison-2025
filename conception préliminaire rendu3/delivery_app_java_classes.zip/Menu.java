import java.util.List;

public class Menu {
    private List<Item> items;

    public List<Item> afficherItems() {
        return items;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }
}