public class Person {
    protected String name;
    protected Address address;
    protected String phoneNumber;
}