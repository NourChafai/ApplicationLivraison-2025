import java.util.List;

public class Gestionnaire {
    private List<User> users;
    private List<Restaurant> restaurants;

    public void modifyUsers() {}
    public void addRestaurant(Restaurant r) {}
    public void removeRestaurant(Restaurant r) {}
}