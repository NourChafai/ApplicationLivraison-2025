public class Item {
    private int id;
    private String name;
    private double price;

    public void setPrice(double price) {
        this.price = price;
    }
}