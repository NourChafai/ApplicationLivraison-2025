import java.util.List;

public class Restaurant {
    private int id;
    private String name;
    private Address address;
    private Menu menu;
    private List<Item> items;

    public Restaurant() {
        this.menu = new Menu();
    }

    public boolean enregistrerCommande(Order commande) {
        System.out.println("Commande reçue par le restaurant.");
        return true;
    }
}