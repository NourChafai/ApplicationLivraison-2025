public class User extends Person {
    private int id;
    private String email;

    public void changeAddress(Address d) {
        this.address = d;
    }
}