import java.util.List;

public class DeliveryPerson extends Person {
    private List<Order> commandesAssignees;
    private Vehicle vehicle;

    public void mettreAJourCommande() {
        List<Order> listeCommandes = consulterCommandesAssignees();
        Order commande = listeCommandes.get(0);
        OrderStatus nouveauStatut = OrderStatus.DELIVERED;
        commande.setStatus(nouveauStatut);
        commande.notifierChangementStatut();
    }

    public List<Order> consulterCommandesAssignees() {
        return commandesAssignees;
    }
}