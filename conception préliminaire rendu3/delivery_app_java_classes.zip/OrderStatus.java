public enum OrderStatus {
    PENDING,
    PROCESSING,
    DELIVERED,
    CANCELLED
}