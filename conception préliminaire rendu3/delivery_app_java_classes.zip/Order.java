public class Order {
    private int id;
    private OrderStatus status;
    private Customer customer;
    private Restaurant restaurant;
    private DeliveryPerson deliveryPerson;
    private List<Item> items;

    public Order(List<Item> items, Customer customer, Restaurant restaurant) {
        this.items = items;
        this.customer = customer;
        this.restaurant = restaurant;
        this.status = OrderStatus.PENDING;
    }

    public void setStatus(OrderStatus nouveauStatut) {
        this.status = nouveauStatut;
    }

    public void notifierChangementStatut() {
        System.out.println("Cher client, le statut de votre commande est maintenant : " + status);
    }
}